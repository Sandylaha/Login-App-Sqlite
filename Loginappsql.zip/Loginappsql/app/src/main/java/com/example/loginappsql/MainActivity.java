package com.example.loginappsql;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {

    EditText mTextUsername;
    EditText mTextPassword;
    Button mButtonLogin;
    TextView mTExtViewRegister;
    databasehelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

db=new databasehelper(this);
        mTextUsername=findViewById(R.id.edittext_username);
        mTextPassword=findViewById(R.id.edittext_password);
        mButtonLogin=findViewById(R.id.button_login);
        mTExtViewRegister=findViewById(R.id.textview_register);

        mTExtViewRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent regIntent=new Intent(MainActivity.this,Register.class);
                startActivity(regIntent);
            }
        });

    mButtonLogin.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String user=mTextUsername.getText().toString().trim();
            String pwd=mTextPassword.getText().toString().trim();
            Boolean res=db.checkUser(user,pwd);
            if(res==true){
                Intent HomePage=new Intent(MainActivity.this,Home.class);
                startActivity(HomePage);
            }
            else{
                Toast.makeText(MainActivity.this,"Login Error",Toast.LENGTH_LONG).show();
            }




        }
    });


    }
}
