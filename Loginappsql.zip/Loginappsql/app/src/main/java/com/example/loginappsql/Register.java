package com.example.loginappsql;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Register extends AppCompatActivity {
    EditText mTextUsername;
    EditText mTextPassword;
    EditText mTextCnfPassword;
    Button mButtonRegister;
    TextView mTExtViewLogin;
    databasehelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        db=new databasehelper(this);
        mTextUsername=findViewById(R.id.edittext_username);
        mTextPassword=findViewById(R.id.edittext_password);
        mTextCnfPassword=findViewById(R.id.edittext_confirm_password);
        mButtonRegister=findViewById(R.id.button_register);
        mTExtViewLogin=findViewById(R.id.textview_login);

        mTExtViewLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent regIntent=new Intent(Register.this,MainActivity.class);
                startActivity(regIntent);
            }
        });
   mButtonRegister.setOnClickListener(new View.OnClickListener() {
       @Override
       public void onClick(View v) {
           String user = mTextUsername.getText().toString().trim();
           String pwd = mTextPassword.getText().toString().trim();
           String cnf_pwd = mTextCnfPassword.getText().toString().trim();

           if (pwd.equals(cnf_pwd)) {
               long val = db.addUser(user, pwd);
               if (val > 0) {
                   Toast.makeText(Register.this, "You have Registered", Toast.LENGTH_SHORT).show();
                   Intent moveToLogin = new Intent(Register.this, MainActivity.class);
                   startActivity(moveToLogin);
               }
               else {
                   Toast.makeText(Register.this, "Registration Error", Toast.LENGTH_SHORT).show();
               }

           }
           else {
               Toast.makeText(Register.this, "Password is not matching", Toast.LENGTH_SHORT).show();
           }
       }


   });




    }
}
